// +build linux

package controllers

var types = []string{
	"ping", "tcpdump", "traceroute", "nslookup",
}
