// +build windows

package controllers

var types = []string{
	"ping", "tcpdump", "tracert", "nslookup",
}
