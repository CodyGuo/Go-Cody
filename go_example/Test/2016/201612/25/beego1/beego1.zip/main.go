package main

import (
	_ "github.com/CodyGuo/Go-Cody/go_example/Test/2016/201612/25/beego1/routers"
	"github.com/astaxie/beego"
)

func main() {
	beego.Run()
}
